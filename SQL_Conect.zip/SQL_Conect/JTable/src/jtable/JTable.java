
package jtable;

public class JTable {

   public static void main(String[] args) {
      
   }
   
}
